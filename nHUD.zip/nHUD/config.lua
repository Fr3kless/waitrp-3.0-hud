Config = {}

Config.hudSettings = {
  SCALE = 100,
  DISPLAY_ELEMENTS = {
    'HEALTH',
    'ARMOUR',
    'HUNGER',
    'THIRST',
    'VOICE',
    'SPEED',
    'STREET',
    'CLOCK',
  }
}