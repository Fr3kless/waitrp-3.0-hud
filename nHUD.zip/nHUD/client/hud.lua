ESX = nil
local isPedInVehicle = false
local speed = 0
local lastSpeed = 0
local lastStreet1 = 0
local hudSettings = nil

DisplayRadar(false)

CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) 
			ESX = obj 
		end)
		
		Citizen.Wait(250)
	end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  ESX.PlayerData = xPlayer
  ESX.PlayerLoaded = true

  Wait(100)

  LOAD_SETTINGS()

  SendNUIMessage({
    type = "HUD_TOGGLE",
    payload = true
  })
end)

-- Citizen.CreateThread(function()
--   Wait(100)

--   LOAD_SETTINGS()

--   SendNUIMessage({
--     type = "HUD_TOGGLE",
--     payload = true
--   })
-- end)

RegisterNetEvent('esx:onPlayerLogout')
AddEventHandler('esx:onPlayerLogout', function()
  ESX.PlayerLoaded = false
  ESX.PlayerData = {}

  SendNUIMessage({
    type = "HUD_TOGGLE",
    payload = false
  })
end)

CreateThread(function()
  while true do
      if IsPauseMenuActive() then
          SendNUIMessage({ type = "IS_PAUSED", payload = false })
      else
          SendNUIMessage({ type = "IS_PAUSED", payload = true })

          local ped = PlayerPedId()
          local health, armour, hunger, thirst = (GetEntityHealth(ped) - 100), GetPedArmour(ped), 0, 0
          TriggerEvent('esx_status:getStatus', 'hunger', function(status)
              hunger = status.getPercent()
          end)
          TriggerEvent('esx_status:getStatus', 'thirst', function(status)
              thirst = status.getPercent()
          end)

--[[           if exports.esx_ambulancejob.isDead() then
              health = 0
          end ]]

          SendNUIMessage({
            type = "UPDATE_PLAYER",
            payload = {
              HEALTH = health,
              ARMOUR = armour,
              HUNGER = hunger,
              THIRST = thirst,
              TALKING = NetworkIsPlayerTalking(PlayerId())
            }
          })
      end

      Citizen.Wait(500)
  end
end)

-- AddEventHandler('esx_status:onTick', function(status)
--   if IsPauseMenuActive() and not isPaused then
--     isPaused = true
--     SendNUIMessage({ type = "IS_PAUSED", payload = false })
--   elseif not IsPauseMenuActive() and isPaused then
--     isPaused = false
--     SendNUIMessage({ type = "IS_PAUSED", payload = true })
--   end

--   if isPaused then
--     return
--   end

--   local playerPed = PlayerPedId()

--   local function getValue(name)
--     for _, v in pairs(status) do
--       if v.name == name then
--         return v.percent
--       end
--     end
--   end

--   SendNUIMessage({
--     type = "UPDATE_PLAYER",
--     payload = {
--       HEALTH = not IsEntityDead(playerPed) and math.ceil(GetEntityHealth(playerPed) - 100) or 0,
--       ARMOUR = GetPedArmour(playerPed),
--       HUNGER = getValue('hunger'),
--       THIRST = getValue('thirst'),
--       TALKING = NetworkIsPlayerTalking(PlayerId())
--     }
--   })
-- end)

Citizen.CreateThread(function()
  while true do
    local playerPed = PlayerPedId()

    isPedInVehicle = IsPedInAnyVehicle(playerPed, false)

    SendNUIMessage({
      type    = "VEHICLE_TOGGLE",
      payload = isPedInVehicle
    })

    DisplayRadar(isPedInVehicle)

    if isPedInVehicle then
      speed = GetEntitySpeed(playerPed)

      if speed ~= lastSpeed then
        SendNUIMessage({
          type = "UPDATE_SPEED",
          payload = (math.ceil(speed* 2.236936))
        })

        lastSpeed = speed
      end
    else
      speed = 0
      lastSpeed = 0
    end

    Citizen.Wait(250)
  end
end)

Citizen.CreateThread(function()
  while true do

    local hours, minutes = GetClockHours(), GetClockMinutes()

    if hours < 10 then
      hours = "0" .. hours
    end

    if minutes < 10 then
      minutes = "0" .. minutes
    end

    SendNUIMessage({
      type = "UPDATE_GAME_TIME",
      payload = hours .. ":" .. minutes
    })

    if isPedInVehicle then
      local coords = GetGameplayCamCoord()
      local street = "Unknown"
      local street1, street2 = GetStreetNameAtCoord(coords.x, coords.y, coords.z, Citizen.ResultAsInteger(),
        Citizen.ResultAsInteger())

      lastStreet1 = street1

      if street1 ~= 0 and street2 ~= 0 and (street1 .. ' & ' .. street2) ~= (lastStreet1 .. ' & ' .. lastStreet1) then
        street = (GetStreetNameFromHashKey(street1) .. ' & ' .. GetStreetNameFromHashKey(street2))
      elseif street1 ~= 0 and street2 == 0 then
        street = GetStreetNameFromHashKey(street1)
      elseif street1 == 0 and street2 ~= 0 then
        street = GetStreetNameFromHashKey(street2)
      end

      SendNUIMessage({
        type = "UPDATE_STREET",
        payload = street .. " | " .. GetLabelText(GetNameOfZone(coords.x, coords.y, coords.z))
      })
    end

    Citizen.Wait(1000)
  end
end)


RegisterKeyMapping("togglehud", "Toggle HUD", "keyboard", "MOUSE_MIDDLE")
RegisterCommand("togglehud", function()
  SendNUIMessage({
    type = "HUD_TOGGLE"
  })
end, false)


RegisterKeyMapping("settingshud", "Toggle Settings", "keyboard", "F11")
RegisterCommand("settingshud", function()
  SendNUIMessage({
    type = "SETTINGS_TOGGLE",
    payload = hudSettings
  })
  SetNuiFocus(true, true)
end, false)


RegisterNUICallback("UPDATE_SETTINGS", function(data, cb)
  hudSettings = data

  SetResourceKvp("nHUD_SETTINGS", json.encode(data))

  SetNuiFocus(false, false)

  cb(hudSettings)
end)

RegisterNUICallback("CLOSE_SETTINGS", function(data, cb)
  SetNuiFocus(false, false)

  cb(hudSettings)
end)


function LOAD_SETTINGS()
  hudSettings = GetResourceKvpString('nHUD_SETTINGS')

  if hudSettings == nil then
    SetResourceKvp('nHUD_SETTINGS', json.encode(Config.hudSettings))

    hudSettings = GetResourceKvpString('nHUD_SETTINGS')
  end

  hudSettings = json.decode(hudSettings)

  SendNUIMessage({
    type = "SETTINGS_UPDATE",
    payload = hudSettings
  })

  Wait(100)
end

AddEventHandler("gameEventTriggered", function(args1, args2)
  if args1 == 'CEventNetworkPlayerEnteredVehicle' and args2[1] == PlayerId() then
    RebuildRadar()
  end
end)

function RebuildRadar()
  RequestStreamedTextureDict("circlemap", false)
  while not HasStreamedTextureDictLoaded("circlemap") do
      Wait(500)
  end

  local defaultAspectRatio = 1920 / 1080
  local resolutionX, resolutionY = GetActiveScreenResolution()
  local aspectRatio = resolutionX / resolutionY
  local minimapOffset = 0
  if aspectRatio > defaultAspectRatio then
    minimapOffset = ((defaultAspectRatio - aspectRatio) / 3.6) - 0.008
  end

  AddReplaceTexture("platform:/textures/graphics", "radarmasksm", "circlemap", "radar")

  SetMinimapClipType(1)
  SetMinimapComponentPosition("minimap", "L", "B", -0.0100 + minimapOffset, -0.030, 0.180, 0.258)
  SetMinimapComponentPosition("minimap_mask", "L", "B", 0.200 + minimapOffset, 0.0, 0.065, 0.20)
  SetMinimapComponentPosition('minimap_blur', 'L', 'B', -0.00 + minimapOffset, 0.055, 0.252, 0.338)
  SetBlipAlpha(GetNorthRadarBlip(), 0)
  SetMinimapClipType(1)

  local minimap = RequestScaleformMovie("minimap")
  SetRadarBigmapEnabled(true, false)
  Wait(0)
  SetRadarBigmapEnabled(false, false)
end