function ShowNotify(data)
  PlaySoundFrontend(-1, "Click", "DLC_HEIST_HACKING_SNAKE_SOUNDS", 1)
  SendNUIMessage({
    type = "NOTIFICATION",
    payload = {
      title = data.title,
      message = data.message,
      autoClose = data.autoClose or 5000,
      position = data.position or "top-center",
    }
  })
end


RegisterCommand("notify", function(s, args)
  ShowNotify({
    title = "Test Title",
    message = table.concat(args, " "),
    position = "bottom-center",
  })
end, false)

exports('ShowNotify', ShowNotify)