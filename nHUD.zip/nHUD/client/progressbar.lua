--[[ local cacheData = {}

exports("OpenProgressBar", ProgressBar)
-- RegisterNetEvent("wait_taskbar:progress", function(data)
-- ProgressBar(data)
-- end)

function ProgressBar(data)
  local _data = {
    label = data.label or "Loading",
    time = data.duration or 5000,
    allowCancel = data.canCancel or false,
    onFinish = data.onFinish or function() end,
    onCancel = data.onCancel or function() end
  }

  cacheData = _data

  SendNUIMessage({
    type = "PROGRESSBAR_START",
    payload = {
      LABEL = _data.label,
      TIME = _data.time,
      MAX = _data.time,
      ALLOW_CANCEL = _data.allowCancel
    }
  })
end

RegisterNUICallback("EVENT", function(data, cb)
  if data.type == "CANCEL" then
    cacheData.onCancel()
  elseif data.type == "FINISH" then
    cacheData.onFinish()
  end

  cb("ok")
end)

RegisterCommand("testprogbar", function()
  ProgressBar({
    label = "Test",
    time = 5000,
    onFinish = function()
      print("finished")
    end,
    onCancel = function()
      print("canceled")
    end
  })
end, false)

RegisterCommand("testprogbar2", function()
  ProgressBar({
    label = "Test xasdas",
    time = 2000,
    onFinish = function()
      print("finished2")
    end,
    onCancel = function()
      print("canceled2")
    end
  })
end, false)

 ]]