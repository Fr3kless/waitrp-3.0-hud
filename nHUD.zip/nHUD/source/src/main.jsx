import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";
import { MantineProvider } from "@mantine/core";
import { NotificationsProvider } from "@mantine/notifications";

import { AppProvider } from "./hooks/AppProvider";

ReactDOM.createRoot(document.getElementById("root")).render(
  <AppProvider>
    <MantineProvider
      withNormalizeCSS
      theme={{
        colorScheme: "dark",
        fontFamily: "Poppins",
        focusRing: false,
      }}
    >
      <NotificationsProvider
        limit={5}
        style={{
          position: "absolute",
          top: "10%",
          right: 0,
        }}
        containerWidth={"30vh"}
      >
        <App />
      </NotificationsProvider>
    </MantineProvider>
  </AppProvider>
);
