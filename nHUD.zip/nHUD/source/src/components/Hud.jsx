import {
  Badge,
  Box,
  Group,
  Indicator,
  Progress,
  Stack,
  Text,
  Title,
  Transition,
} from "@mantine/core";
import {
  IconHeart,
  IconWall,
  IconSoup,
  IconBottle,
  IconMicrophone,
} from "@tabler/icons";
import { useContext } from "react";

import { AppContext } from "../hooks/AppProvider";

const Hud = () => {
  const { state, dispatch } = useContext(AppContext);

  const MPH = (mph) => {
    if (mph < 10) {
      return "00" + mph;
    } else if (mph < 100) {
      return "0" + mph;
    } else {
      return mph;
    }
  };

  return (
    <Transition
      transition="slide-up"
      mounted={
        state.HUD_OPEN &&
        state.SETTINGS.SCALE &&
        state.SETTINGS.DISPLAY_ELEMENTS.length > 0
      }
      timingFunction="ease-in-out"
      duration={200}
    >
      {(styles) => (
        <Box
          sx={{
            ...styles,
            height: "100vh",
          }}
        >
          <Stack
            spacing="xs"
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-end",

              position: "absolute",
              bottom: "0",
              right: "0",
              transform: "scale(" + state.SETTINGS.SCALE / 100 + ")",
              transformOrigin: "bottom right",
            }}
            mb="3vh"
          >
            <Transition
              transition="slide-left"
              mounted={
                state.VEHICLE_OPEN &&
                state.SETTINGS.DISPLAY_ELEMENTS.includes("STREET")
              }
              timingFunction="ease-in-out"
              duration={500}
            >
              {(styles) => (
                <Box
                  p="xs"
                  style={{
                    ...styles,
                    backgroundImage:
                      "linear-gradient(to right, transparent, rgba(45,44,39,0.6) 20%)",
                  }}
                >
                  <Title
                    order={4}
                    color="white"
                    align="end"
                    ml={"3vh"}
                    sx={{
                      fontFamily: "Poppins",
                      fontWeight: 600,
                    }}
                  >
                    {state.CURRENT_STREET}
                  </Title>
                </Box>
              )}
            </Transition>

            <Box
              p="xs"
              style={{
               backgroundImage:
                      "linear-gradient(to right, transparent, rgba(45,44,39,0.6) 20%)",
              }}
            >
              <Group
                position="right"
                spacing="md"
                sx={{
                  marginLeft: "4.5vh",
                }}
              >
                <Transition
                  transition="slide-left"
                  mounted={
                    state.VEHICLE_OPEN &&
                    state.SETTINGS.DISPLAY_ELEMENTS.includes("SPEED")
                  }
                  timingFunction="ease-in-out"
                  duration={500}
                >
                  {(styles) => (
                    <Box
                      style={{
                        ...styles,
                      }}
                    >
                      <Indicator inline label="MPH" size="lg" color={"#0190fe"}>
                        <Badge
                          variant="filled"
                          size="lg"
                          styles={{
                            root: {
                              backgroundColor: "#0190fe",
                            },
                          }}
                        >
                          {MPH(state.CURRENT_SPEED)}
                        </Badge>
                      </Indicator>
                    </Box>
                  )}
                </Transition>

                <Transition
                  transition="pop"
                  mounted={state.SETTINGS.DISPLAY_ELEMENTS.includes("VOICE")}
                  timingFunction="ease-in-out"
                  duration={200}
                >
                  {(styles) => (
                    <IconMicrophone
                      style={{
                        ...styles,
                      }}
                      color={state.PLAYER_STATS.TALKING ? "#0190fe" : "white"}
                      size={20}
                    />
                  )}
                </Transition>

                <Transition
                  transition="pop"
                  mounted={state.SETTINGS.DISPLAY_ELEMENTS.includes("CLOCK")}
                  timingFunction="ease-in-out"
                  duration={200}
                >
                  {(styles) => (
                    <Badge
                      style={{
                        ...styles,
                      }}
                      styles={{
                        root: {
                          backgroundColor: "#0190fe",
                        },
                      }}
                      variant="filled"
                      size="lg"
                    >
                      <Text color="white">{state.CLOCK}</Text>
                    </Badge>
                  )}
                </Transition>

                <Transition
                  transition="pop"
                  mounted={state.SETTINGS.DISPLAY_ELEMENTS.includes("HEALTH")}
                  timingFunction="ease-in-out"
                  duration={200}
                >
                  {(styles) => (
                    <div
                      style={{
                        ...styles,
                        position: "relative",
                        display: "inline-block",
                      }}
                    >
                      <Progress
                        value={state.PLAYER_STATS.HEALTH}
                        color="#0190fe"
                        style={{
                          width: "3vh",
                          height: "3vh",
                          transform: "rotate(-90deg)",
                        }}
                      />
                      <IconHeart
                        color="white"
                        style={{
                          position: "absolute",
                          top: "50%",
                          left: "50%",
                          transform: "translate(-50%, -50%)",
                        }}
                      />
                    </div>
                  )}
                </Transition>

                <Transition
                  transition="pop"
                  mounted={
                    state.PLAYER_STATS.ARMOUR > 0 &&
                    state.SETTINGS.DISPLAY_ELEMENTS.includes("ARMOUR")
                  }
                  timingFunction="ease-in-out"
                  duration={200}
                >
                  {(styles) => (
                    <div
                      style={{
                        position: "relative",
                        ...styles,
                      }}
                    >
                      <Progress
                        value={state.PLAYER_STATS.ARMOUR}
                        color="#0190fe"
                        style={{
                          width: "3vh",
                          height: "3vh",
                          transform: "rotate(-90deg)",
                        }}
                      />
                      <IconWall
                        color="white"
                        style={{
                          position: "absolute",
                          top: "50%",
                          left: "50%",
                          transform: "translate(-50%, -50%)",
                        }}
                      />
                    </div>
                  )}
                </Transition>

                <Transition
                  transition="pop"
                  mounted={state.SETTINGS.DISPLAY_ELEMENTS.includes("HUNGER")}
                  timingFunction="ease-in-out"
                  duration={200}
                >
                  {(styles) => (
                    <div
                      style={{
                        ...styles,
                        position: "relative",
                        display: "inline-block",
                      }}
                    >
                      <Progress
                        value={state.PLAYER_STATS.HUNGER}
                        color="#0190fe"
                        style={{
                          width: "3vh",
                          height: "3vh",
                          transform: "rotate(-90deg)",
                        }}
                      />
                      <IconSoup
                        color="white"
                        style={{
                          position: "absolute",
                          top: "50%",
                          left: "50%",
                          transform: "translate(-50%, -50%)",
                        }}
                      />
                    </div>
                  )}
                </Transition>

                <Transition
                  transition="pop"
                  mounted={state.SETTINGS.DISPLAY_ELEMENTS.includes("THIRST")}
                  timingFunction="ease-in-out"
                  duration={200}
                >
                  {(styles) => (
                    <div
                      style={{
                        ...styles,
                        position: "relative",
                        display: "inline-block",
                      }}
                    >
                      <Progress
                        value={state.PLAYER_STATS.THIRST}
                        color="#0190fe"
                        style={{
                          width: "3vh",
                          height: "3vh",
                          transform: "rotate(-90deg)",
                        }}
                      />
                      <IconBottle
                        color="white"
                        style={{
                          position: "absolute",
                          top: "50%",
                          left: "50%",
                          transform: "translate(-50%, -50%)",
                        }}
                      />
                    </div>
                  )}
                </Transition>
              </Group>
            </Box>
          </Stack>
        </Box>
      )}
    </Transition>
  );
};

export default Hud;
