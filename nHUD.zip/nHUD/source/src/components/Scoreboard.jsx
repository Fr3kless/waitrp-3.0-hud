import {
  Box,
  Stack,
  Text,
  Title,
  Transition,
} from "@mantine/core";

import { useContext } from "react";
import { AppContext } from "../hooks/AppProvider";

const Scoreboard = () => {
  const { state, dispatch } = useContext(AppContext);

  return (
    <Box
      sx={{
        position: "absolute",
        top: "40%",
        right: "0",

        transform: "scale(" + state.SETTINGS.SCALE / 100 + ")",
        transformOrigin: "center right",
      }}
    >
      <Transition
        transition="slide-left"
        mounted={state.SCOREBOARD_OPEN}
        timingFunction="ease-in-out"
        duration={500}
      >
        {(styles) => (
          <Box
            p="xs"
            sx={{
              ...styles,
              backgroundImage:
              "linear-gradient(to right, transparent, rgba(45,44,39,0.6) 20%)",
            }}
          >
            <Stack ml={"3vh"}>
              <Title
                order={1}
                color="white"
                mx={"xl"}
                align="center"
                sx={{
                  fontFamily: "Poppins",
                  fontWeight: 600,
                }}
              >
                Wait Roleplay
              </Title>

              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
              >
                <Text
                  color="white"
                  size="xl"
                  sx={{
                    fontFamily: "Poppins",
                    fontWeight: 600,
                  }}
                >
                  LSPD: {state.ONDUTY_LIST.LSPD || 0}
                </Text>

                <Text
                  color="white"
                  size="xl"
                  sx={{
                    fontFamily: "Poppins",
                    fontWeight: 600,
                  }}
                >
                  EMS: {state.ONDUTY_LIST.EMS || 0}
                </Text>

                <Text
                  color="white"
                  size="xl"
                  sx={{
                    fontFamily: "Poppins",
                    fontWeight: 600,
                  }}
                >
                  LSC: {state.ONDUTY_LIST.LSC || 0}
                </Text>
              </Box>

              <Title
                order={4}
                color="white"
                align="center"
                sx={{
                  fontFamily: "Poppins",
                  fontWeight: 600,
                }}
              >
                Praca: {state.JOB_LABEL}
              </Title>
            </Stack>
          </Box>
        )}
      </Transition>
    </Box>
  );
};

export default Scoreboard;
