import {
  Box,
  Group,
  Progress,
  Stack,
  Text,
  Title,
  Transition,
} from "@mantine/core";

import { useEffect, useContext, useState } from "react";

import { AppContext } from "../hooks/AppProvider";
import AppFetch from "../hooks/AppFetch";

const Progressbar = () => {
  const { state, dispatch } = useContext(AppContext);

  const [currentTime, setCurrentTime] = useState(0);

  useEffect(() => {
    if (state.PROGRESSBAR_OPEN) {
      setTimeout(() => {
        AppFetch("EVENT", {
          type: "FINISH",
        }).then(() => {
          dispatch({
            type: "PROGRESSBAR_STOP",
          });

          setCurrentTime(0);
        });
      }, state.PROGRESSBAR.TIME);

      const interval = setInterval(() => {
        setCurrentTime((currentTime) => currentTime + 1000);
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [state.PROGRESSBAR_OPEN]);

  const convertTimeToProgressbar = (time) => {
    return 100 * (currentTime / time);
  };

  return (
    <Box
      sx={{
        position: "absolute",
        bottom: "0",
        left: "50%",
        transform: "translateX(-50%) scale(" + state.SETTINGS.SCALE / 100 + ")",
        transformOrigin: "bottom center",
      }}
    >
      <Transition
        transition="pop"
        mounted={state.PROGRESSBAR_OPEN}
        timingFunction="ease-in-out"
        duration={500}
      >
        {(styles) => (
          <Box
            mb="3vh"
            p="xs"
            sx={{
              ...styles,

              backgroundImage:
                "linear-gradient(90deg, transparent 0%, rgba(45,44,39,0.6) 20%, rgba(45,44,39,0.6) 80%, rgba(0,0,0,0.01) 100%)",
            }}
          >
            <Stack
              spacing={0}
              sx={{
                width: "30vh",
                marginLeft: "4.5vh",
                marginRight: "4.5vh",
              }}
            >
              <Text color="white">
                {state.PROGRESSBAR.LABEL}
              </Text>
              <Progress
                value={convertTimeToProgressbar(state.PROGRESSBAR.TIME)}
                color="blue"
                size="xs"
              />
            </Stack>
          </Box>
        )}
      </Transition>
    </Box>
  );
};

export default Progressbar;
