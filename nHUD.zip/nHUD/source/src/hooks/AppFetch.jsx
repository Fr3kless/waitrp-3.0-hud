import axios from "axios";

const AppFetch = async (url, data) => {
  const res = await axios.post(
    `https://${GetParentResourceName()}/${url}`,
    data
  );

  return res.data;
};

export default AppFetch;
