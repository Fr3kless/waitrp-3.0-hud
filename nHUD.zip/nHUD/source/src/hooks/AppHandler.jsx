import { useEffect, useContext } from "react";
import { showNotification } from "@mantine/notifications";

import { AppContext } from "./AppProvider";

const AppHandler = () => {
  const { dispatch } = useContext(AppContext);

  useEffect(() => {
    const messagesHandler = (event) => {
      const { type, payload } = event.data;

      if (type === "NOTIFICATION") {
        showNotification({
          disallowClose: true,
          autoClose: payload.autoClose,
          title: payload.title,
          message: payload.message,

          position: payload.position,
          styles: (theme) => ({
            root: {
              backgroundColor: "transparent",
              backgroundImage:
                "linear-gradient(to right, transparent, rgba(45,44,39,0.6) 20%)",
              border: "none",
              borderRadius: 0,
              padding: "0.5vh 1.5vh",
              "&::before": { backgroundColor: "#0190fe" },
            },

            title: { color: theme.white },
            description: { color: theme.white },
          }),
        });
      } else {
        dispatch({ type, payload });
      }
    };

    window.addEventListener("message", messagesHandler);

    return () => {
      window.removeEventListener("message", messagesHandler);
    };
  }, []);
};

export default AppHandler;
