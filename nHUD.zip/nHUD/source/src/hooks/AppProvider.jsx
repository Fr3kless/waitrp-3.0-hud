import { createContext, useReducer } from "react";

const AppContext = createContext([]);

const AppProvider = ({ children }) => {
  const [state, dispatch] = useReducer(
    (state, action) => {
      switch (action.type) {
        case "IS_PAUSED":
          return {
            ...state,
            IS_PAUSED: action.payload,
          };

        case "HUD_TOGGLE":
          return {
            ...state,
            HUD_OPEN: action.payload || !state.HUD_OPEN,
          };

        case "SCOREBOARD_TOGGLE":
          return {
            ...state,
            SCOREBOARD_OPEN: !state.SCOREBOARD_OPEN,
            ONDUTY_LIST: action.payload.ONDUTY_LIST,
            JOB_LABEL: action.payload.JOB_LABEL,
          };

        case "UPDATE_PLAYER":
          return {
            ...state,
            PLAYER_STATS: action.payload,
          };

        case "UPDATE_GAME_TIME":
          return {
            ...state,
            CLOCK: action.payload,
          };

        case "VEHICLE_TOGGLE":
          return {
            ...state,
            VEHICLE_OPEN: action.payload,
          };

        case "UPDATE_STREET":
          return {
            ...state,
            CURRENT_STREET: action.payload,
          };

        case "UPDATE_SPEED":
          return {
            ...state,
            CURRENT_SPEED: action.payload,
          };

        case "SETTINGS_TOGGLE":
          return {
            ...state,
            SETTINGS_OPEN: !state.SETTINGS_OPEN,
            SETTINGS: action.payload,
          };

        case "SETTINGS_UPDATE":
          return {
            ...state,
            SETTINGS: action.payload,
          };

        case "SETTINGS_CLOSE":
          return {
            ...state,
            SETTINGS_OPEN: false,
          };

        case "SETTINGS_EDIT":
          return {
            ...state,
            SETTINGS: {
              ...state.SETTINGS,
              [action.payload.key]: action.payload.value,
            },
          };

        case "SETTINGS_EDIT_DISPLAY":
          return {
            ...state,
            SETTINGS: {
              ...state.SETTINGS,
              DISPLAY_ELEMENTS: action.payload,
            },
          };

        case "PROGRESSBAR_START":
          return {
            ...state,
            PROGRESSBAR_OPEN: true,
            PROGRESSBAR: action.payload,
          };

        case "PROGRESSBAR_STOP":
          return {
            ...state,
            PROGRESSBAR_OPEN: false,
          };

        default:
          return state;
      }
    },
    {
      IS_PAUSED: true,

      SCOREBOARD_OPEN: false,
      ONDUTY_LIST: {
        LSPD: 0,
        EMS: 0,
        LSC: 0,
      },
      JOB_LABEL: "Brak",

      HUD_OPEN: false,
      PLAYER_STATS: {},
      CLOCK: "00:00",

      VEHICLE_OPEN: false,
      CURRENT_STREET: "Los Santos",
      CURRENT_SPEED: 0,

      SETTINGS_OPEN: false,
      SETTINGS: {
        SCALE: 100,
        DISPLAY_ELEMENTS: [],
      },

      PROGRESSBAR_OPEN: false,
      PROGRESSBAR: {
        LABEL: "Label",
        TIME: 0,
        ALLOW_CANCEL: false,
      },
    }
  );

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export { AppContext, AppProvider };
