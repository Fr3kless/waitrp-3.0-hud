import { useContext } from "react";

import {
  Box,
  Avatar,
  Modal,
  Stack,
  Slider,
  Button,
  Checkbox,
} from "@mantine/core";

import AppHandler from "./hooks/AppHandler";
import { AppContext } from "./hooks/AppProvider";
import AppFetch from "./hooks/AppFetch";

import Hud from "./components/Hud";
import Scoreboard from "./components/Scoreboard";
import Progressbar from "./components/Progressbar";

const App = () => {
  const { state, dispatch } = useContext(AppContext);

  AppHandler();

  return (
    <Box
      sx={{
        height: "100vh",
        overflow: "hidden",
        display: state.IS_PAUSED ? "block" : "none",
      }}
    >
      <Avatar
        src="https://cdn.discordapp.com/attachments/1052686905629741096/1053342192674033754/logo.png"
        radius="md"
        size={80}
        sx={{
          position: "absolute",
          top: "1rem",
          right: "1rem",

          transform: "scale(" + state.SETTINGS.SCALE / 100 + ")",
          transformOrigin: "top right",

         

        }}
      />

      <Hud />

      <Scoreboard />

      <Progressbar />

      <Modal
        opened={state.SETTINGS_OPEN && state.HUD_OPEN}
        onClose={() => {
          AppFetch("CLOSE_SETTINGS").then((res) => {
            dispatch({ type: "SETTINGS_TOGGLE", payload: res });
          });
        }}
        title="Ustawienia HUD"
        centered
      >
        <Stack spacing="xs">
          <Slider
            label={(value) => "Skala: " + value + "%"}
            min={50}
            max={200}
            value={state.SETTINGS.SCALE}
            onChange={(value) =>
              dispatch({
                type: "SETTINGS_EDIT",
                payload: { key: "SCALE", value: value },
              })
            }
          />

          <Checkbox.Group
            orientation="vertical"
            label="Wybierz elementy do wyświetlenia"
            description="Zaznaczone elementy będą wyświetlane na ekranie"
            withAsterisk
            spacing="xs"
            value={state.SETTINGS.DISPLAY_ELEMENTS}
            onChange={(value) => {
              dispatch({
                type: "SETTINGS_EDIT_DISPLAY",
                payload: value,
              });
            }}
          >
            <Checkbox value="HEALTH" label="Życie" />
            <Checkbox value="ARMOUR" label="Kamizelka" />
            <Checkbox value="HUNGER" label="Głód" />
            <Checkbox value="THIRST" label="Pragnienie" />
            <Checkbox value="VOICE" label="Głos" />
            <Checkbox value="CLOCK" label="Zegar" />
            <Checkbox value="SPEED" label="Prędkość" />
            <Checkbox value="STREET" label="Ulica" />
          </Checkbox.Group>

          <Button.Group>
            <Button
              onClick={() => {
                AppFetch("UPDATE_SETTINGS", state.SETTINGS).then((res) => {
                  dispatch({ type: "SETTINGS_TOGGLE", payload: res });
                });
              }}
            >
              Zapisz
            </Button>
            <Button
              onClick={() => {
                AppFetch("CLOSE_SETTINGS").then((res) => {
                  dispatch({ type: "SETTINGS_TOGGLE", payload: res });
                });
              }}
            >
              Anuluj
            </Button>
          </Button.Group>
        </Stack>
      </Modal>
    </Box>
  );
};

export default App;
